# Echo — Full-stack prototype

This version connects the Echo frontend to a small Node.js backend.

## What is included

- `index.html` — frontend + CSS + browser JavaScript
- `server.js` — Node backend and API
- `data/db.json` — prototype JSON database
- `package.json` — start script

## Run locally

1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run:

```bash
npm start
```

4. Open `http://localhost:3000`.

Do **not** double-click `index.html` for this version. The backend needs to serve it.

## Backend features

- Account registration/login with hashed passwords
- HttpOnly session cookie
- Memory creation and deletion
- Public/discover memory feed
- Structured + keyword prototype matching
- Private verification endpoint
- Match consent choices
- Anonymous questions
- Privacy settings
- Report/block endpoints
- Health endpoint at `/health`

## Important prototype limitation

The JSON database is intentionally simple so the project has no external dependencies. It is suitable for learning and a small prototype, not for storing real sensitive memories or launching publicly at scale. Before real users, replace it with a managed database, add production authentication/session storage, rate limiting, CSRF protection, moderation, audit logging, encrypted sensitive fields, backups, and a proper semantic matching service.

The matching algorithm is deliberately labeled as a prototype and is **not** real AI.
